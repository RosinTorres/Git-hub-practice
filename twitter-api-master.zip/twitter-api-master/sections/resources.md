[<<< Previous](scraping_data.md) | [Back to beginning >>>](../README.md)

# API Resources

[Creating Web APIs with Python and Flask on the Programming Historian](https://programminghistorian.org/en/lessons/creating-apis-with-python-and-flask)  
[Web APIs with Python tutorial at DHSI](https://github.com/szweibel/DHSI-API-workshop)  
[Programmable Web](http://www.programmableweb.com), a list of web-based APIs you can use in your projects.  
[Twitterbot Examples](http://nymag.com/following/2015/11/12-weirdest-funniest-smartest-twitter-bots.html)  
[Tweepy Documentation](http://docs.tweepy.org/en/v3.5.0/)  

[<<< Previous](scraping_data.md) | [Back to beginning >>>](../README.md)
